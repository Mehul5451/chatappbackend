const express = require("express");
const http = require("http");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const cors = require("cors");
const dotenv = require("dotenv");
const { Server } = require("socket.io");

const app = express();
dotenv.config();

app.use(cors());
app.use(express.json());

const server = http.createServer(app);
const port = process.env.PORT || 3000;

// MongoDB connection and models
require("./conn");
const { ChatUser , Message } = require("./modu");

const io = new Server(server, {
  cors: {
    origin: "http://localhost:5173",
    methods: ["GET", "POST"]
  }
});

// ===== JWT Auth Middleware =====
const authMiddleware = (req, res, next) => {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ message: "Unauthorized: No token provided" });
  }

  const token = authHeader.split(" ")[1];
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(401).json({ message: "Unauthorized: Invalid token" });
  }
};

// ======= Auth Routes =======
app.post("/submit", async (req, res) => {
  const { name, email, phone, password } = req.body;
  const oldUser = await ChatUser.findOne({ email });
  if (oldUser) return res.status(409).send("User already exists");

  const hashedPassword = await bcrypt.hash(password, 10);
  const newUser = new ChatUser({ name, email, phone, password: hashedPassword });
  await newUser.save();
  res.status(201).send("User registered successfully");
});

app.post("/login", async (req, res) => {
  const { email, password } = req.body;
  const user = await ChatUser.findOne({ email });
  if (!user) return res.status(404).send("User not found");

  const isMatch = await bcrypt.compare(password, user.password);
  if (!isMatch) return res.status(401).send("Invalid credentials");

  const token = jwt.sign({ id: user._id, email: user.email }, process.env.JWT_SECRET, {
    expiresIn: "1h",
  });

  res.status(200).json({ token, user });
});

app.get("/getuser", async (req, res) => {
  const users = await ChatUser.find();
  res.json(users);
});

app.get('/messages/:senderId/:receiverId', async (req, res) => {
  const { senderId, receiverId } = req.params;
  const messages = await Message.find({
    $or: [
      { senderId, receiverId },
      { senderId: receiverId, receiverId: senderId }
    ]
  }).sort({ timestamp: 1 });
  res.json(messages);
});

const userSocketMap = {};

io.on("connection", (socket) => {
  socket.on("register_user", (userId) => {
    userSocketMap[userId] = socket.id;
  });

  socket.on("send_message", async ({ senderId, receiverId, message }) => {
    const newMsg = new Message({ senderId, receiverId, message });
    await newMsg.save();
    const receiverSocket = userSocketMap[receiverId];
    if (receiverSocket) io.to(receiverSocket).emit("receive_message", { senderId, message });
  });

  socket.on("disconnect", () => {
    for (const [userId, socketId] of Object.entries(userSocketMap)) {
      if (socketId === socket.id) delete userSocketMap[userId];
    }
  });
});

server.listen(3000, () => console.log("Server running on http://localhost:3000"));